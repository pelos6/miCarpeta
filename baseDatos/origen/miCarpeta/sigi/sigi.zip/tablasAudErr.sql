------------------------------------------------
-- Export file for user EDUSIGIPREP           --
-- Created by jiranzo on 10/07/2015, 13:41:50 --
------------------------------------------------

spool tablasAudErr.log

prompt
prompt Creating table SIGI_AUD
prompt =======================
prompt
@@sigi_aud.tab
prompt
prompt Creating table SIGI_ERR
prompt =======================
prompt
@@sigi_err.tab

spool off
