------------------------------------------------
-- Export file for user EDUSIGIPREP           --
-- Created by jiranzo on 10/07/2015, 13:42:23 --
------------------------------------------------

spool paquetes.log

prompt
prompt Creating package SIGI_PCK
prompt =========================
prompt
@@sigi_pck.spc
prompt
prompt Creating package SIGI_UTIL_PCK
prompt ==============================
prompt
@@sigi_util_pck.spc
prompt
prompt Creating package body SIGI_PCK
prompt ==============================
prompt
@@sigi_pck.bdy
prompt
prompt Creating package body SIGI_UTIL_PCK
prompt ===================================
prompt
@@sigi_util_pck.bdy

spool off
